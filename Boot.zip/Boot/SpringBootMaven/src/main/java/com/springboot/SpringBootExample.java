package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class SpringBootExample {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootExample.class, args);
	}
	
	@RequestMapping("/call")
	public String getMessage(){
		return "Call Me Dear";
	}
}
